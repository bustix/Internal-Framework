# Contributing

## Using the issue tracker

The issue tracker on GitHub is the preferred channel for bug reports and feature requests.

## Pull requests

